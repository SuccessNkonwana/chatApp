const config = {
    // apiKey: "AIzaSyAk0794OsQuDuoEdUfF9nUM_zD17lfRXEE",
    // authDomain: "codedamn-socialapp.firebaseapp.com",
    // databaseURL: "https://codedamn-socialapp.firebaseio.com",
    // projectId: "codedamn-socialapp",
    // storageBucket: "codedamn-socialapp.appspot.com",
    // messagingSenderId: "263473733320"
    apiKey: "AIzaSyAhHQh055ZhoG4Ry2qbijZUVp_Vajr8hBw",
    authDomain: "chatroom-a3ad0.firebaseapp.com",
    databaseURL: "https://chatroom-a3ad0.firebaseio.com",
    projectId: "chatroom-a3ad0",
    storageBucket: "chatroom-a3ad0.appspot.com",
    messagingSenderId: "341583722213",
    appId: "1:341583722213:web:b84d6067faa6ef38"
}

export default config